// encrypt-decrypt key
module.exports = {
    secret: "SECRET"
};